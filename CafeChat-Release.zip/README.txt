Start the shortcut which executes a windows .exe for the CafeChat-Server.
Server will read from CafeChat-Production.

Silly Tavern must be running on port 8000 of localhost with valid Claude3 Key